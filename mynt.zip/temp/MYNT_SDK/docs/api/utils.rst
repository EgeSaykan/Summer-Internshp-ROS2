.. _utils:

Utils
=====

select
------

.. doxygenfunction:: select
   :project: mynteyes

select_request
--------------

.. doxygenfunction:: select_request
   :project: mynteyes

get_real_exposure_time
----------------------

.. doxygenfunction:: get_real_exposure_time
   :project: mynteyes

get_sdk_root_dir
----------------

.. doxygenfunction:: get_sdk_root_dir
   :project: mynteyes

get_sdk_install_dir
-------------------

.. doxygenfunction:: get_sdk_install_dir
   :project: mynteyes

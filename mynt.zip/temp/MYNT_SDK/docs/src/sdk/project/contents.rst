.. _data:

SDK Project Demos
==================

.. toctree::
  :maxdepth: 2

  cmake
  vs2017
# MYNT® EYE Android Wrapper

## Prerequisites

Android device need be rooted and support [USB3 OTG](https://en.wikipedia.org/wiki/USB_On-The-Go) feature.

## Build & Run

1. Download and install [Android Studio](https://developer.android.com/studio/index.html)
2. Start Android Studio and [download the NDK and build tools](https://developer.android.com/studio/projects/add-native-code)
3. Open this project using `Open an existing Android Studio project`

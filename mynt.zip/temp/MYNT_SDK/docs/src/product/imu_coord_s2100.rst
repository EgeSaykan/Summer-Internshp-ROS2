.. _product_imu_coord_s2100:

S2100 Coordinate System
====================================

IMU coordinate system is right-handed,the axis directions are as follows:

.. image:: ../../images/product/mynteye_s2_imu_coord.jpg

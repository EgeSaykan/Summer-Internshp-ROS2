.. _mynteye_surface_s2100:

S2100 Size and Structure
================================

============= ==============
Shell(mm)     PCBA board(mm)
============= ==============
125x47x40     100x15
============= ==============

.. image:: ../../images/product/mynteye_s2_surface_zh-Hans.jpg

A. Camera:please pay attention to protect the camera sensor lenses, to avoid imaging quality degradation.
B. USB Micro-B interface and set screw holes: during usage, plug in the USB Micro-B cable and secure it by fastening the set screws to avoid damage to the interface and to ensure stability in connection.

//
//  main.m
//  UVC Test App
//
//  Created by bagheera on 9/26/14.
//  Copyright (c) 2014 Vidvox. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}

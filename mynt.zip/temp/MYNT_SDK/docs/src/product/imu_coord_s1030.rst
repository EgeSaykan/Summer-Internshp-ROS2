.. _product_imu_coord_s1030:

S1030 Coordinate System
====================================

IMU coordinate system is right-handed,the axis directions are as follows:

.. image:: ../../images/product/mynteye_imu_coord.jpg

// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from tutorial_interfaces_test:msg/Num.idl
// generated code does not contain a copyright notice

#ifndef TUTORIAL_INTERFACES_TEST__MSG__DETAIL__NUM__TYPE_SUPPORT_H_
#define TUTORIAL_INTERFACES_TEST__MSG__DETAIL__NUM__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "tutorial_interfaces_test/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_tutorial_interfaces_test
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  tutorial_interfaces_test,
  msg,
  Num
)();

#ifdef __cplusplus
}
#endif

#endif  // TUTORIAL_INTERFACES_TEST__MSG__DETAIL__NUM__TYPE_SUPPORT_H_

# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for write_device_info.

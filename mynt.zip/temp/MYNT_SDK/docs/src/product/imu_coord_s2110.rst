.. _product_imu_coord_s2110:

S2110 Coordinate System
====================================

IMU coordinate system is right-handed,the axis directions are as follows:

.. image:: ../../images/product/mynteye_s2110_imu_coord.jpg

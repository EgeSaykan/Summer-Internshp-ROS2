.. _api:

API
===

API
---

.. doxygenclass:: mynteye::API
   :project: mynteyes
   :members:

api::StreamData
---------------

.. doxygenstruct:: mynteye::api::StreamData
   :project: mynteyes
   :members:

api::MotionData
---------------

.. doxygenstruct:: mynteye::api::MotionData
   :project: mynteyes
   :members:

#import <Cocoa/Cocoa.h>

@interface NSString (VVUVCKitStringAdditions)

- (BOOL) containsString:(NSString *)n;

@end

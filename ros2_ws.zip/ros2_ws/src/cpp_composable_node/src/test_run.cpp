

#include <chrono>
#include <functional>
#include <memory>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include <rclcpp_components/register_node_macro.hpp>

using namespace std::chrono_literals;


namespace palomino
{
  class  : public rclcpp::Node
  {
  public:
    TestDriver(const rclcpp::NodeOptions & options) : Node("test_driver", options)
      {
        // ...
      }
  }
}

RCLCPP_COMPONENTS_REGISTER_NODE(palomino::TestDriver)


Contact Us
==================

If you continue to encounter problems, please contact customer service. 

http://support.myntai.com/hc/request/new/
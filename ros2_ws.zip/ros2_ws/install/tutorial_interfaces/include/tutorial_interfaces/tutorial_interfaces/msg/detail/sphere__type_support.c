// generated from rosidl_generator_c/resource/idl__type_support.c.em
// with input from tutorial_interfaces:msg/Sphere.idl
// generated code does not contain a copyright notice

#include <string.h>

#include "tutorial_interfaces/msg/detail/sphere__functions.h"
#include "rosidl_typesupport_interface/macros.h"
#include "tutorial_interfaces/msg/detail/sphere__struct.h"
#include "tutorial_interfaces/msg/detail/sphere__type_support.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif

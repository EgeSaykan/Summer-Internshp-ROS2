// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtlesim:srv/Kill.idl
// generated code does not contain a copyright notice

#ifndef TURTLESIM__SRV__KILL_H_
#define TURTLESIM__SRV__KILL_H_

#include "turtlesim/srv/detail/kill__struct.h"
#include "turtlesim/srv/detail/kill__functions.h"
#include "turtlesim/srv/detail/kill__type_support.h"

#endif  // TURTLESIM__SRV__KILL_H_

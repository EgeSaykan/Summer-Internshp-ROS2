# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for camera_with_junior_device_api.

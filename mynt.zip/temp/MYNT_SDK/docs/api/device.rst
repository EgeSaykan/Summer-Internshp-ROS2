.. _device:

Device
======

Device
------

.. doxygenclass:: mynteye::Device
   :project: mynteyes
   :members:

device::Frame
-------------

.. doxygenclass:: mynteye::device::Frame
   :project: mynteyes
   :members:

device::StreamData
------------------

.. doxygenstruct:: mynteye::device::StreamData
   :project: mynteyes
   :members:

device::MotionData
------------------

.. doxygenstruct:: mynteye::device::MotionData
   :project: mynteyes
   :members:

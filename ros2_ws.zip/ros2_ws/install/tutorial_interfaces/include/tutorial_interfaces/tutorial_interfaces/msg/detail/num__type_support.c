// generated from rosidl_generator_c/resource/idl__type_support.c.em
// with input from tutorial_interfaces:msg/Num.idl
// generated code does not contain a copyright notice

#include <string.h>

#include "tutorial_interfaces/msg/detail/num__struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "tutorial_interfaces/msg/detail/num__type_support.h"
#include "tutorial_interfaces/msg/detail/num__functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif

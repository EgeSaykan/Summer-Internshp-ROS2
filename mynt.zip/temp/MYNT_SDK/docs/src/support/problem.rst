FAQ
==================

If you have problems using MYNT EYE, please first check the following docs：

http://support.myntai.com/hc/
.. _fw_update:

Firmware Update
==================

.. toctree::
   :maxdepth: 2

   update_main_chip
   update_auxiliary_chip

.. _sdk_info:

SDK Description
==================

.. toctree::
   :maxdepth: 2

   support_platforms
   without_opencv
